# Kostur: društvo s više naroda, v0.3

Kostur je implementiran prema prijedlogu ugovora v0.4. Ovo je radna verzija kostura v0.3.

## Šta je u folderu

| Datoteka | Sadržaj |
| --- | --- |
| `tri-naroda.nlogox` | NetLogo 7.0.4 model, setup/go, interfejs i eksperimenti |
| `jezgro.nls` | Svijet, osobe, domovi, firme, institucije, ekonomija, selidba, API i mjere |
| `demografija.nls`, `kriza.nls` | Odvojeni godišnji slojevi demografije i krize |
| `modul-susreti.nls` | Kuća, posao, škola, kafić, prodavnica |
| `modul-mediji.nls` | Mediji i selektivna izloženost odraslih |
| `modul-zaposljavanje.nls` | Prednost svoje grupe pri izboru radnika |
| `mehanizam.nls` | Prazan šablon za tim s prefiksom |
| `napravi_model.py`, `oblici.xml` | Samostalan generator i lokalni oblici |
| `parametri.json` | Početne vrijednosti kontrola, generisane zajedno s modelom |
| `provjera/` | Sažetak provjera |

## Pokretanje, slojevi i mehanizam tima

Otvoriti `tri-naroda.nlogox`. Početne parametre svijeta, institucija i firmi postaviti **prije setupa**. Za drugi period u BehaviorSpaceu uskladiti `trajanje` i ograničenje `timeLimit` u generatoru. Početni interfejs je L0; `osnovni` koristi L1–L3. Prekidači su `plate-razlicite?`, `putovanje?`, `demografija?`; kriza je godina veća od 0 ili `slucajne-krize?`. Moduli i prazan mehanizam početno su isključeni.

Redoslijed godine: demografija → kriza i obnova → mediji → susreti → mehanizam tima → tržište rada → novac → selidbe (posao, susjedstvo, ostalo) → invarijante i mjere. Godina krize 1 je prvi `go`. Prikaz boji osobe po grupi, identitetu ili prihodu i koristi lokalni tok slučajnih brojeva. Firme i institucije su male i sive.

1. Dopuniti `mehanizam-setup` i `mehanizam-korak`; dodatne procedure i atribute označiti prefiksom, npr. `rodbina-`. Atribut osobe dodaje se jednom u `turtles-own`.
2. Dodati svoje kontrole u generator, regenerisati model i uključiti `mehanizam?`. Za više mehanizama koristiti odvojene prekidače i pozive. Jezgro se može mijenjati. Tim u radu navodi svaku izmjenu jezgra i razlog za nju.
3. Koristiti API iz §8: `promijeni-identitet`, `korist-selidbe`, `pokusaj-selidbu`, `udio-grupe-u`, `manjak-svojih`, `neto-prihod`, `clanovi`, `odrasli`, `djeca`, `korpa`, `ispod-korpe?`. `cetvrti` i `mjesta` su liste patch-setova; `grupe` lista aktivnih breedova. `udio-grupe-u` prihvata breed ili oznaku, a mjere koriste oznake A–D, `ostali`, `mjesovito`, `sve` gdje su primjenjive.
4. `odrasli` u porodici su svi od 18 godina, uključujući penzionere. Tržište rada zasebno koristi 18–64. Udio grupe za odluke o selidbi je zajednički snimak na početku redovnih selidbi.
5. `razlozi` i `selidbe-po-razlogu` imaju redoslijed: `nema`, `posao`, `susjedstvo`, `odvajanje`, `skola`, `rodbina`, `ostalo`. Atribut doma čuva posljednji razlog; lista broji samo tekuću godinu.
6. Mehanizam pokazati na najnižem potrebnom sloju i na punom modelu. Par s mehanizmom i bez njega koristi isto sjeme, a ponavljanja različita sjemena.

Model se ponovo izrađuje skriptom `napravi_model.py`. Paket ne sadrži skripte za provjeru ni detaljne rezultate. Sažetak je u `provjera/sazetak.json`.

## Provjere s brojkama

Završni skup sadrži **148 headless pokretanja**, svako do stvarnog `ticks = 20`. Provjereno je podudaranje stvarnog ticka s korakom BehaviorSpacea. Invarijante se izvršavaju nakon setupa i svake godine: članstvo i adresa osobe, zauzetost stana, neprazno domaćinstvo, novac i atributi u granicama, postojeći i dostupan posao, kapacitet firme i dob za školu/rad. Dodatna skripta provjerava jednačinu stanovništvo = početak + rođeni − umrli u svakoj godini.

Pojedinačni i kumulativni slojevi, sjemena 101, 102 i 103. Tabela daje prosjek po sjemenima; selidbe su zbir kroz cijeli period, ostalo završna stanja. Izvor: slojevi.csv.

| Sloj | D četvrti, kraj | Selo, kraj | Dob sela, kraj | Selidbe posao, zbir | Putnici | Zarobljeni |
| --- | --- | --- | --- | --- | --- | --- |
| L0 | 0,5912 | 2228,67 | 29,46 | 39,33 | 0,00 % | 1,75 % |
| L1 | 0,6294 | 2232,33 | 29,36 | 85,67 | 0,00 % | 3,34 % |
| L2 | 0,6440 | 2239,00 | 29,49 | 20,67 | 38,00 % | 3,31 % |
| L3 | 0,6834 | 2500,67 | 34,70 | 27,67 | 41,19 % | 3,38 % |
| L4 | 0,6841 | 2496,00 | 35,13 | 29,00 | 49,34 % | 3,48 % |
| L2-samo | 0,6511 | 2228,00 | 29,56 | 34,33 | 4,34 % | 2,26 % |
| L3-samo | 0,6029 | 2599,67 | 34,26 | 37,67 | 0,00 % | 2,18 % |
| L4-samo | 0,5855 | 2208,33 | 29,56 | 66,33 | 0,00 % | 2,65 % |


Početni prosjek D je 0,6247; početno stanovništvo sela 2286,33, a dob sela 29,36 godina. L2 smanjuje prosječan zbir selidbi zbog posla s 85,67 na 20,67. L3 povećava dob sela na 34,70, ali im broj stanovnika raste zbog rođenja. L4 blago povećava završni udio zarobljenih; sve selidbe ne prestaju.

- **L0, izdvojeno:** D po sjemenima 101: 0,2350 → 0,4008; 102: 0,2415 → 0,3869; 103: 0,2296 → 0,3600. Teritorije su mješovite, težina identiteta 4, slučajne selidbe isključene, ambicija se postavi na nulu. schelling.csv.
- **L1, izdvojeno:** uz jednake plate završni prosjek stanovnika velikih gradova je 624,33, uz različite 767,00. Udio mješovitih firmi je 0,4222 prema 0,4778. Oba kraka imaju iste zadate probne plate 2,5 / 1,5 / 0,8, rasipanje 0, identitet i slučajne selidbe 0; razlikuje se samo prekidač plata. L1-izdvojeno.csv.
- **Isključeni slojevi i prikaz:** promjene neaktivnih parametara plata, putnog troška, demografije, krize i modula dale su potpuno jednak niz mjera. Jednak je i uz promjenu bojenja. Bez demografije ostaju isti broj osoba i zbir njihovih starosti. iskljuceni.csv.
- **Sjemena:** isto sjeme daje potpuno jednak niz izmjerenih stanja, drugo sjeme različit. Sama oznaka sjemena isključena je iz poređenja. ponovljivost.csv, logicke-provjere.json.
- **Demografija:** provjereno 1136 zapisa rođenja: grupa djeteta jednaka je grupi doma, a identitet tačno ograničen prosjek odraslih plus sačuvano odstupanje. Redovni prolaz ima 139 odvajanja u dobi 25–35, uključujući 32 iz sela u grad i 135 iz početne školske kohorte. Prisilni pokus uz ispunjene uslove daje 375 odvajanja. Naplata roditeljskom domu i početni novac novog doma 0 potvrđeni su za svaki zapis. demografija-dogadjaji.csv, odvajanje-prisilno.csv, dogadjaji-putanje.json.
- **Dobne granice:** prolaz s početnim dobima 5, 17 i 64 prelazi školu, punoljetstvo i penziju. Bez smrti svaka osoba ostari tačno 20 godina. Invarijante provjeravaju školu i posao nakon prelaza. dobne-granice.csv.
- **Kriza:** šok u godini 10 u T1, jačine 0,9, smanjuje ušteđevinu s 1105,716065 na 110,571607, zatvara 18 od 20 firmi i otpušta 348 radnika. Provjeren je i slučajni režim s događajem svake godine te račun da izvan T1 nema gubitka i da se uz `p-obnove = 1` firme otvore sljedeće godine. kriza-dogadjaji.csv, kriza-racun.csv.
- **API i tržište rada:** poznati primjer potvrđuje izbor najsposobnijeg i, uz modul, izbor svoje grupe; novac nakon korpe je 11,00, identitet 0,72, koristi selidbe -0,15 i 0,85, novac nakon selidbe 0,85. Izdvojena kriza daje pozitivnu korist 3,45, novac 0,03 i tačnu oznaku zarobljenosti. api.csv, api-kriza.csv.
- **Rubovi i moduli:** prošle su sve kombinacije prekidača modula, grupe 2 i 4 s podijeljenim institucijama, prazan i pun svijet te potpuno izumiranje. Svi ugovoreni reporteri rade pri praznoj populaciji. moduli.csv, svijet-rubovi.csv.
- **Trajanje:** početno 3515 osoba i 1197 domaćinstava, sjeme 101; 20 godina od završetka setupa traje 14,447 s. Cijeli proces traje 25,703 s, uključujući pokretanje, kompilaciju i setup. Timer uključuje godišnje reportere, prikaz i invarijante. To je jedno mjerenje, nije mjerenje čistog jezgra ni poređenje hardvera. vrijeme.csv.

## Kontrolni scenarij i demografska ravnoteža

Ugrađeni `kontrolni` izvršen je s različitim sjemenima. Identitet, uključujući novorođenčad, ostaje 0; ekonomija i demografija rade. Početak, kraj i ekstremi kroz period:

| Sjeme | Početak | Kraj | Min | Max | Promjena |
| --- | --- | --- | --- | --- | --- |
| 1000 | 3535 | 4085 | 3535 | 4085 | 15,56 % |
| 1001 | 3633 | 4206 | 3633 | 4206 | 15,77 % |
| 1002 | 3506 | 4119 | 3506 | 4119 | 17,48 % |
| 1003 | 3462 | 3978 | 3462 | 3978 | 14,90 % |
| 1004 | 3525 | 4095 | 3525 | 4095 | 16,17 % |
| 1005 | 3551 | 4061 | 3551 | 4061 | 14,36 % |
| 1006 | 3665 | 4244 | 3665 | 4244 | 15,80 % |
| 1007 | 3634 | 4258 | 3634 | 4258 | 17,17 % |
| 1008 | 3598 | 4250 | 3598 | 4250 | 18,12 % |
| 1009 | 3494 | 3981 | 3494 | 3981 | 13,94 % |


Izvori: kontrolni.csv, kontrolni-populacija.csv.

Dodatni pokus mijenja samo `stopa-radjanja` na probnih **0,04**, uz iste kontrolne postavke i sjemena:

| Sjeme | Početak | Kraj | Min | Max | Promjena |
| --- | --- | --- | --- | --- | --- |
| 1000 | 3535 | 3516 | 3512 | 3559 | -0,54 % |
| 1001 | 3633 | 3571 | 3571 | 3634 | -1,71 % |
| 1002 | 3506 | 3527 | 3506 | 3552 | 0,60 % |
| 1003 | 3462 | 3398 | 3391 | 3470 | -1,85 % |
| 1004 | 3525 | 3548 | 3525 | 3583 | 0,65 % |
| 1005 | 3551 | 3496 | 3496 | 3563 | -1,55 % |
| 1006 | 3665 | 3670 | 3651 | 3696 | 0,14 % |
| 1007 | 3634 | 3630 | 3628 | 3672 | -0,11 % |
| 1008 | 3598 | 3612 | 3595 | 3621 | 0,39 % |
| 1009 | 3494 | 3504 | 3489 | 3510 | 0,29 % |


Izvori: kalibracija-004.csv, kalibracija-004-populacija.csv. Ovo je provjera stabilnosti apstraktnog modela, bez potvrde popisnim podacima.

## BehaviorSpace eksperimenti

Iz samog modela pokrenuti su `kontrolni` i `osnovni`, po 10 ponavljanja, te `zarada-i-identitet`, po 10 za težine 0, 1, 2, 3 i 4. Svi traju 20 godina i izvoze ugovorene mjere godišnje. Sjemena su 1000–1009, ponovljena po krakovima težine radi uparenih početnih stanja. `tezina-zarade` je uvijek 1. Završni prosjeci:

| Težina identiteta | D četvrti | Mješovite firme | Zarobljeni | Putnici |
| --- | --- | --- | --- | --- |
| 0 | 0,5386 | 0,4977 | 0,0088 | 0,4129 |
| 1 | 0,6186 | 0,5195 | 0,0269 | 0,4224 |
| 2 | 0,6706 | 0,4452 | 0,0372 | 0,4431 |
| 3 | 0,6949 | 0,4623 | 0,0429 | 0,4658 |
| 4 | 0,7091 | 0,4836 | 0,0428 | 0,4785 |


Izvori: osnovni.csv, zarada-i-identitet.csv. Brojke su ishodi probnih postavki, nisu zaključci o stvarnim narodima.

## Odstupanja od ugovora i otvorena pitanja

- **Populacija uz ugovorenu probnu stopu 0,08 nije približno stalna:** raste 13,94–18,12 %. Probna stopa **0,04** daje promjenu -1,85–0,65 % uz ista sjemena. Radni kriterij provjere je konačna promjena unutar ±5 %; to nije odredba ugovora ni empirijska kalibracija. Osnovna vrijednost u v0.3 ostaje 0,08.
- Ugovor ne određuje sve početne ekonomske vrijednosti u novim jedinicama. Dodatne **probne** postavke su: `plata-jedinstvena` 1,3; sredina eksponencijalnog `novac-pocetni` 2; `trosak-selidbe` 0,15 i `trosak-granice` 0,1. `prag` 0,5 i `tezina-identiteta` 2 također su probni, bez empirijske kalibracije.
- **Ponuda posla (§4.2):** poboljšanje se provjerava stvarnim ličnim neto prihodom, sa sposobnošću i putnim troškom. Ne uvodi se dodatni zasebni prag nominalne plate firme prema sadašnjem ličnom neto prihodu. Ovo tumačenje prati formulu prijave.
- `roditelji` pamti odrasle članove pri stvaranju djeteta; `dijete-u-domu?` razlikuje dijete od osnivača doma. Odvajanje traži živog roditelja u istom domu. Preživjela djeca bez odraslih ostaju u stanu; starateljstvo se ne modelira. Grupa doma bez odraslih izvodi se iz preostale djece. Za rođenje u mješovitom domu kostur prijavljuje jasnu grešku dok tim ne odredi pravilo grupe i dogovori tačku proširenja; takvi domovi u samom kosturu ne nastaju.
- `ostali` koriste `identitet-ostali`, bez korekcije za udio „svojih“, jer za njih ta grupa nije definisana. U podijeljenim školama idu u prvu školu mjesta.
- Plata iz normalne raspodjele ograničena je odozdo na strogo pozitivnu vrijednost. Ukupan kapacitet mjesta se zaokruži, a ostatak raspodijeli firmama. Pri izjednačenju većine bira se prva aktivna grupa A–D. Ako birač sastava navede neaktivnu grupu, početni sastav postaje ravnomjeran među aktivnima.
- Početni kapaciteti firmi ne rastu s populacijom; demografski rast zato može povećati nezaposlenost. Kriza zatvara firme, zadržavajući agente: mijenja se broj otvorenih firmi, ne broj agentskih zapisa. Slučajni režim ima prednost nad fiksnom godinom. Nova zatvorena firma ne obnavlja se u istom ticku.
- Domaćinstvo se seli najviše jednom godišnje, uključujući odvajanje. Ponude rezervišu kapacitet do odluke porodice i potom propadaju ako nisu prihvaćene. Uspjela selidba uklanja oznaku zarobljenosti.
- OECD formula primjenjuje se doslovno i na dom sastavljen samo od maloljetnika. Nema posebne socijalne politike. U kontrolnom scenariju odstupanje identiteta novorođenčeta dodatno je postavljeno na 0 da sve osobe ostanu na identitetu 0.
- Očekivani agregatni smjerovi nisu garancije. Izdvojeni L1 potvrđuje tok prema gradovima pri većoj razlici plata, dok osnovne postavke daju slabiji i nejednoznačan učinak. Kriza ne zaustavlja sve selidbe; poznati račun potvrđuje njeno zarobljavanje doma s pozitivnom koristi selidbe. Formule nisu prilagođavane poželjnom ishodu.

## Šta nije provjereno

Empirijska kalibracija i potvrda sljedećim popisom, izgled GUI-ja na ekranu, duži periodi, mehanizmi timova i mješoviti brakovi. Rat i inostrane migracije nisu u kosturu. Univerziteti postoje, ali ih kostur ne koristi. Nema tvrdnje o realnosti probnih raspodjela.

Sažetak: [sazetak.json](provjera/sazetak.json).
