"""Pravi samostalan NetLogo 7.0.4 model iz lokalnih .nls datoteka.

Pokretanje: python -I napravi_model.py. Ne mijenja ulazne datoteke.
"""
from pathlib import Path
from xml.sax.saxutils import escape, quoteattr
import json

ROOT = Path(__file__).resolve().parent
# Ime, najmanje, najviše, korak, probna početna vrijednost.
SLIDERS = [
    ('sjeme', 0, 100000, 1, 104729), ('trajanje', 1, 100, 1, 20),
    ('broj-grupa', 2, 4, 1, 3), ('gustina', 0, 1, .05, .8),
    ('udio-vecine', .5, .99, .01, .8), ('udio-ostalih', 0, .5, .01, .03),
    ('identitet-prosjek', 0, 1, .05, .5), ('identitet-sd', 0, .5, .01, .15),
    ('identitet-ostali', 0, 1, .05, .2), ('efekat-okruzenja', 0, 1, .01, .2),
    ('ambicija-prosjek', 0, 1, .05, .2), ('prag', 0, 1, .05, .5),
    ('tezina-identiteta', 0, 4, .1, 2), ('broj-kandidata', 1, 30, 1, 5),
    ('p-slucajne-selidbe', 0, .2, .01, .02),
    ('trosak-selidbe', 0, 3, .05, .15), ('trosak-granice', 0, 3, .05, .1),
    ('novac-pocetni', 0, 10, .1, 2), ('korpa-osnovna', .1, 3, .1, 1),
    ('faktor-veliki-grad', .5, 2, .1, 1.2), ('faktor-manji-grad', .5, 2, .1, 1.1),
    ('faktor-selo', .5, 2, .1, 1), ('plata-jedinstvena', .1, 4, .1, 1.3),
    ('plata-veliki-grad', .1, 4, .1, 1.6), ('plata-manji-grad', .1, 4, .1, 1.3),
    ('plata-selo', .1, 4, .1, 1), ('rasipanje-plata', 0, .5, .01, .15),
    ('stopa-radnih-mjesta', 0, 1.5, .05, .7), ('p-gubitak-posla', 0, .5, .01, .05),
    ('socijalna-pomoc', 0, 2, .1, .3), ('penzija', 0, 2, .1, .6),
    ('trosak-puta', 0, .2, .005, .01), ('max-putovanje', 0, 100, 1, 15),
    ('djece-selo', 0, 4, .1, 1.8), ('djece-grad', 0, 4, .1, 1.2),
    ('stopa-radjanja', 0, .5, .01, .08), ('odstupanje-identiteta', 0, .5, .01, .05),
    ('p-odvajanja', 0, 1, .01, .08),
    ('p-smrti-do-64', 0, .2, .001, .002), ('p-smrti-65-74', 0, .5, .01, .02),
    ('p-smrti-75-84', 0, .5, .01, .06), ('p-smrti-85-plus', 0, 1, .01, .15),
    ('godina-krize', 0, 100, 1, 0), ('p-krize', 0, 1, .01, .05),
    ('jacina-krize', .1, .9, .1, .5), ('p-obnove', 0, 1, .05, .2),
    ('prag-mjesovito', .25, 1, .01, .66),
    ('broj-susreta-kuca', 0, 10, 1, 3), ('broj-susreta-posao', 0, 10, 1, 3),
    ('broj-susreta-skola', 0, 10, 1, 2), ('broj-susreta-kafic', 0, 10, 1, 2),
    ('broj-susreta-prodavnica', 0, 10, 1, 1), ('radijus-susjedstva', 0, 10, 1, 2),
    ('uticaj-susreta', 0, .5, .01, .05), ('efekat-kontakta', 0, .2, .005, .005),
    ('tezina-kuce', 0, 3, .1, 1), ('tezina-posla', 0, 3, .1, 1.5),
    ('tezina-skole', 0, 3, .1, 1), ('tezina-kafica', 0, 3, .1, .7),
    ('tezina-prodavnice', 0, 3, .1, .2),
    ('uticaj-medija', 0, .5, .01, .05), ('cilj-nacionalnih', 0, 1, .05, 1),
    ('cilj-opstih', 0, 1, .05, .2), ('selektivnost', 0, 1, .05, .1),
    ('jacina-zaposljavanja-svojih', 0, 1, .05, .8),
]
SWITCHES = {'plate-razlicite?': False, 'putovanje?': False, 'demografija?': False,
            'slucajne-krize?': False, 'podijeljen-grad?': False, 'skole-zajednicke?': True,
            'modul-mediji?': False, 'modul-susreti?': False,
            'modul-zaposljavanje?': False, 'mehanizam?': False}
SASTAVI = ['vecina A', 'vecina B', 'vecina C', 'vecina D', 'pola A-B',
           'pola A-C', 'pola A-D', 'pola B-C', 'pola B-D', 'pola C-D', 'mjesovito']
CHOOSERS = {'sastav-T1': (SASTAVI, 'vecina A'), 'sastav-T2': (SASTAVI, 'vecina B'),
            'sastav-T3': (SASTAVI, 'pola A-C'),
            'obuhvat-krize': (['svijet', 'T1', 'T2', 'T3'], 'svijet'),
            'prikaz': (['grupa', 'identitet', 'prihod'], 'grupa')}
DEFAULTS = {s[0]: s[4] for s in SLIDERS} | SWITCHES | {k: v[1] for k, v in CHOOSERS.items()}

CODE = ''';; Kostur v0.3, ugovor v0.4. Jedan tick je jedna godina.
__includes [ "jezgro.nls" "demografija.nls" "kriza.nls" "modul-mediji.nls" "modul-susreti.nls" "modul-zaposljavanje.nls" "mehanizam.nls" ]

to setup
  jezgro-setup
  mediji-setup
  if mehanizam? [ mehanizam-setup ]
  reset-ticks
  osvjezi-prikaz
end

to go
  if ticks >= trajanje [ stop ]
  set selidbe-ovaj-tick n-values length razlozi [ 0 ]
  set rodjeni-ovaj-tick 0
  set umrli-ovaj-tick 0
  set odvojeni-ovaj-tick 0
  ask domacinstva [ set zarobljeno? false set preseljeno? false ]
  if demografija? [ demografija-korak ]
  kriza-korak
  if modul-mediji? [ mediji-korak ]
  if modul-susreti? [ susreti-korak ]
  if mehanizam? [ mehanizam-korak ]
  trziste-rada
  jezgro-novac
  izracunaj-sastav-cetvrti
  jezgro-selidbe
  provjeri-invarijante
  osvjezi-prikaz
  tick
end
'''

METRIKE = ['sjeme', 'ticks', 'count osobe', 'count domacinstva', 'count firme',
           'indeks-razlicitosti "cetvrt"', 'indeks-razlicitosti "mjesto"',
           'indeks-razlicitosti "teritorija"', 'broj-mjesovitih "cetvrt"',
           'broj-mjesovitih "mjesto"', 'broj-mjesovitih "teritorija"',
           'selidbe-po-razlogu', 'udio-putnika', 'udio-mjesovitih-radnih-mjesta',
           'udio-zarobljenih', 'udio-mjesovitih-domacinstava', 'mjesta-bez-djece',
           'udio-nacionalnih-medija', 'rodjeni-ovaj-tick', 'umrli-ovaj-tick',
           'odvojeni-ovaj-tick', 'sum [novac] of domacinstva', 'count firme with [not otvorena?]']
for tip in ['selo', 'manji-grad', 'veliki-grad', 'sve']:
    METRIKE += [f'stanovnistvo "{tip}"', f'prosjecna-starost "{tip}"']
for g in ['A', 'B', 'C', 'D', 'ostali', 'mjesovito', 'sve']:
    METRIKE += [f'udio-ispod-korpe "{g}"', f'ekvivalentni-prihod "{g}"', f'nezaposlenost "{g}"']
    METRIKE += [f'prosjecan-identitet "{g}" "{t}"' for t in ['selo', 'manji-grad', 'veliki-grad', 'sve']]

def nl(v):
    if isinstance(v, bool): return str(v).lower()
    if isinstance(v, str): return '"' + v + '"'
    return str(v)

def experiment(name, values, reps=10, metrics=None, setup=None):
    sets = ''
    for var, vals in values.items():
        if not isinstance(vals, list): vals = [vals]
        sets += f'<enumeratedValueSet variable={quoteattr(var)}>'
        sets += ''.join(f'<value value={quoteattr(nl(v))}></value>' for v in vals)
        sets += '</enumeratedValueSet>'
    setup = setup or 'set sjeme 1000 + ((behaviorspace-run-number - 1) mod 10) setup'
    return f'''<experiment name={quoteattr(name)} repetitions="{reps}" sequentialRunOrder="true" runMetricsEveryStep="true" timeLimit="20">
      <setup>{escape(setup)}</setup><go>go</go><exitCondition>ticks &gt;= trajanje</exitCondition>
      <metrics>{''.join('<metric>' + escape(m) + '</metric>' for m in (metrics or METRIKE))}</metrics>
      <subExperiments><subExperiment>{sets}</subExperiment></subExperiments>
    </experiment>'''

KONTROLNI = {'identitet-prosjek': 0, 'identitet-sd': 0, 'identitet-ostali': 0,
             'efekat-okruzenja': 0, 'odstupanje-identiteta': 0,
             'modul-mediji?': False, 'modul-susreti?': False, 'modul-zaposljavanje?': False,
             'mehanizam?': False, 'godina-krize': 0, 'slucajne-krize?': False,
             'skole-zajednicke?': True, 'podijeljen-grad?': False, 'trosak-granice': 0,
             'plate-razlicite?': True, 'putovanje?': True, 'demografija?': True, 'trajanje': 20}

def main():
    widgets = ['''<view x="5" y="45" width="720" height="480" minPxcor="0" maxPxcor="89" minPycor="0" maxPycor="59" patchSize="8.0" wrappingAllowedX="false" wrappingAllowedY="false" frameRate="30.0" fontSize="10" updateMode="1" showTickCounter="true" tickCounterLabel="godina"></view>''']
    for x, cmd, forever in [(5, 'setup', False), (115, 'go', True), (225, 'osvjezi-prikaz', False)]:
        widgets.append(f'<button x="{x}" y="5" width="105" height="35" display="{cmd}" kind="Observer" forever="{str(forever).lower()}" disableUntilTicks="false">{cmd}</button>')
    for i, (disp, expr) in enumerate([('Osobe', 'count osobe'), ('Domaćinstva', 'count domacinstva'),
         ('D četvrti', 'indeks-razlicitosti "cetvrt"'), ('Putnici', 'udio-putnika'),
         ('Zarobljeni', 'udio-zarobljenih'), ('Selidbe', 'selidbe-po-razlogu')]):
        widgets.append(f'<monitor x="{5 + i % 3 * 240}" y="{535 + i // 3 * 55}" width="230" height="50" precision="4" fontSize="11" display={quoteattr(disp)}>{escape(expr)}</monitor>')
    controls = [('switch', k, v) for k, v in SWITCHES.items()]
    controls += [('chooser', k, v) for k, v in CHOOSERS.items()]
    controls += [('slider', s[0], s) for s in SLIDERS]
    for i, (kind, var, value) in enumerate(controls):
        x, y = 740 + i // 20 * 220, 5 + i % 20 * 47
        if kind == 'switch':
            widgets.append(f'<switch x="{x}" y="{y}" width="210" height="33" variable="{var}" display="{var}" on="{str(value).lower()}"></switch>')
        elif kind == 'chooser':
            vals, cur = value
            choices = ''.join(f'<choice type="string" value={quoteattr(v)}></choice>' for v in vals)
            widgets.append(f'<chooser x="{x}" y="{y}" width="210" height="45" variable="{var}" display="{var}" current="{vals.index(cur)}">{choices}</chooser>')
        else:
            _, mn, mx, step, default = value
            widgets.append(f'<slider x="{x}" y="{y}" width="210" height="33" variable="{var}" display="{var}" min="{mn}" max="{mx}" step="{step}" default="{default}" direction="Horizontal"></slider>')
    full = {'plate-razlicite?': True, 'putovanje?': True, 'demografija?': True}
    experiments = experiment('kontrolni', KONTROLNI) + experiment('osnovni', full)
    experiments += experiment('zarada-i-identitet', full | {'tezina-identiteta': [0, 1, 2, 3, 4]})
    shapes = (ROOT / 'oblici.xml').read_text(encoding='utf-8')
    info = '''Kostur v0.3 po ugovoru v0.4. Jedan tick je jedna godina. Probne vrijednosti nisu kalibrisane.
Početni interfejs: L0; BehaviorSpace osnovni: L3. Slojevi se uključuju redom: različite plate, putovanje,
demografija, kriza. Moduli i prazan mehanizam imaju vlastite prekidače.
Dokumentacija i izmjerene provjere: README.md i provjera/sazetak.json.
Univerziteti su pripremljeni za mehanizam tima.'''
    text = f'''<?xml version="1.0" encoding="utf-8"?>
<model version="NetLogo 7.0.4" snapToGrid="false">
<code><![CDATA[{CODE}]]></code><widgets>{''.join(widgets)}</widgets>
<info><![CDATA[{info}]]></info>{shapes}<previewCommands>setup repeat 20 [go]</previewCommands>
<experiments>{experiments}</experiments></model>'''
    (ROOT / 'tri-naroda.nlogox').write_text(text, encoding='utf-8')
    (ROOT / 'parametri.json').write_text(json.dumps(DEFAULTS, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(f'Napravljen model; kontrola: {len(controls)}, mjera po eksperimentu: {len(METRIKE)}.')

if __name__ == '__main__': main()
